package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class panicButtonScreen extends AppCompatActivity {
    public static boolean panicIsTrue = false;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Events");

    public void panicButtonIsClicked(View panicButton) {

        myRef.child("panic").setValue(true);

        Toast.makeText(this, "PANIC BUTTON IS CLICKED!", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, InformationScreen.class);
        startActivity(intent);
    }

    public void cancelButtonIsClicked(View cancelButton) {
        myRef.child("panic").setValue(false);
    }

    public void dashboardButtonIsClicked(View dashboardButton){
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }


    private void createNotificationChanel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "testChanel";
            String description = "Chanel for test";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);

            NotificationManager x = getSystemService(NotificationManager.class);
            x.createNotificationChannel(channel);
        }
    }
    public void toggle(String command) throws CameraAccessException {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            CameraManager cameraManager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;

            if(cameraManager != null){
                cameraId = cameraManager.getCameraIdList()[0];
            }
            if(cameraManager !=null){
                if(command.equals("on")){
                    cameraManager.setTorchMode(cameraId,true);
                }else{
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panic_button_screen);
        
        Intent intent = new Intent(this, BackGroundProcess.class);
        startService(intent);

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.alarmsound);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                panicIsTrue = Boolean.parseBoolean(dataSnapshot.child("panic").getValue().toString());
                //  Toast.makeText(panicButtonScreen.this, "" + panicIsTrue, Toast.LENGTH_SHORT).show();


                if (panicIsTrue == true) {
                    mp.start();
                    try {
                        toggle("on");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                    createNotificationChanel();

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(panicButtonScreen.this, "test")
                            .setSmallIcon(R.drawable.ic_security_black_24dp)
                            .setContentTitle("Alert!")
                            .setContentText("There is a shooter on campus")
                            .setPriority(NotificationCompat.PRIORITY_HIGH);

                    Intent intent = new Intent(panicButtonScreen.this, InformationScreen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("message","TEST");

                    PendingIntent pendingIntent = PendingIntent.getActivity(panicButtonScreen.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                    builder.setContentIntent(pendingIntent);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(panicButtonScreen.this);
                    notificationManager.notify(100, builder.build());

                }

                if (panicIsTrue == false) {
                    mp.pause();
                    try {
                        toggle("off");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }

        });
    }
}
