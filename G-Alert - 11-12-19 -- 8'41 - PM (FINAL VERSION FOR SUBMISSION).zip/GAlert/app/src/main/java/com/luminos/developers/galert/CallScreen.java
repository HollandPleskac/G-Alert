package com.luminos.developers.galert;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telecom.Call;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class CallScreen extends AppCompatActivity {
    // Global Strings
    private static final int REQUEST_CALL = 1;
    public static boolean panicIsTrue = false;
    public static String usernameOfLocalUser;
    public static String IdofStudent;
    public static String numberOneInt;
    public static String numberTwoInt;
    public static String relationOneString;
    public static String relationTwoString;

    public void getLocalUser(){
        String x = "";
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");
        Log.i("MyTag",usernameOfLocalUser+"");
        IdofStudent = sharedPreferences.getString("studentID", "error");

    }

    public void getRelationNumbers(){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Student").child(IdofStudent);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                numberOneInt = dataSnapshot.child("Phone Number One").getValue().toString();
                numberTwoInt = dataSnapshot.child("Phone Number Two").getValue().toString();
                relationOneString = dataSnapshot.child("Relation One").getValue().toString();
                relationTwoString = dataSnapshot.child("Relation Two").getValue().toString();
                setValuesInStrings();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void setValuesInStrings(){
        TextView nameOne = findViewById(R.id.relationOneLabel);
        TextView nameTwo = findViewById(R.id.relationTwoLabel);

        nameOne.setText(relationOneString);
        nameTwo.setText(relationTwoString);
    }

    public void dashboardButtonIsClicked(View dashboardButton){
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }

    private void makePhoneCall(String phoneNumber){
        if (phoneNumber.trim().length() >0 ){
            if (ContextCompat.checkSelfPermission(CallScreen.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(CallScreen.this,
                        new String[] {Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            }else{
                String dial = "tel:" + phoneNumber;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }

        } else{
            Toast.makeText(this, "Enter a valid phone number", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CALL){
            if(grantResults.length > 0 && grantResults[0] ==  PackageManager.PERMISSION_GRANTED){
                makePhoneCall("12096277732");
            }
        } else{
            Toast.makeText(this, "Call permission not granted.", Toast.LENGTH_SHORT).show();
        }
    }

    public void CallOneIsPressed(View CallButtonOne){
        makePhoneCall(numberOneInt);
    }

    public void CallTwoIsPressed(View CallButtonTwo){
        makePhoneCall(numberTwoInt);
    }

    public void NineOneOneCallIsPressed(View nineOneOneCalllButton){
        makePhoneCall("12096505503");
    }

    public void toggle(String command) throws CameraAccessException {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            CameraManager cameraManager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;

            if(cameraManager != null){
                cameraId = cameraManager.getCameraIdList()[0];
            }
            if(cameraManager !=null){
                if(command.equals("on")){
                    cameraManager.setTorchMode(cameraId,true);
                }else{
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        }
    }
    private void createNotificationChanel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "testChanel";
            String description = "Chanel for test";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);

            NotificationManager x = getSystemService(NotificationManager.class);
            x.createNotificationChannel(channel);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_screen);
        getLocalUser();
        getRelationNumbers();

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.alarmsound);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Events");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                panicIsTrue = Boolean.parseBoolean(dataSnapshot.child("panic").getValue().toString());


                if (panicIsTrue == true) {
                    mp.start();
                    try {
                        toggle("on");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                    createNotificationChanel();

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(CallScreen.this, "test")
                            .setSmallIcon(R.drawable.ic_security_black_24dp)
                            .setContentTitle("Alert!")
                            .setContentText("There is a shooter on campus")
                            .setPriority(NotificationCompat.PRIORITY_HIGH);

                    Intent intent = new Intent(CallScreen.this, InformationScreen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("message","TEST");

                    PendingIntent pendingIntent = PendingIntent.getActivity(CallScreen.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                    builder.setContentIntent(pendingIntent);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(CallScreen.this);
                    notificationManager.notify(100, builder.build());

                }

                if (panicIsTrue == false) {
                    mp.pause();
                    try {
                        toggle("off");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                }


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }

        });
    }
}
