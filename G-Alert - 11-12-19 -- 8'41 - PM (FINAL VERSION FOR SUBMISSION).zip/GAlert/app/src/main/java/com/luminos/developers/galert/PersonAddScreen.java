package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Person;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PersonAddScreen extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    // Global Variables
    public static String usernameOfLocalUser;
    public static String schoolID;
    public static String personRole = "";
    public static boolean panicIsTrue = false;

    public void getLocalUser(){
        String x = "";
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");
        Log.i("MyTag",usernameOfLocalUser+"");

    }

    public void addPersonButtonIsClicked(View person_add_button){
        Intent intent = new Intent(this, PersonAddScreen.class);
        startActivity(intent);
    }

    public void addStudentButtonIsClicked(View addStudentButton) {

        EditText studentIDEntry = findViewById(R.id.studentIdEntry);
        EditText studentNameEntry = findViewById(R.id.studentNameEntry);

        String studentID = studentIDEntry.getText().toString();
        String studentName = studentNameEntry.getText().toString();

        if (studentID.equals("") || studentName.equals("") || personRole.equals("")) {
            Toast.makeText(this, "Fields cannot be left blank!", Toast.LENGTH_SHORT).show();
        } else {

            //Initialize Firebase
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child(personRole).child(studentID);

            if(personRole == "Staff"){
                myRef.child("Staff Username").setValue(studentID);
                myRef.child("Name").setValue(studentName);
                studentIDEntry.setText("");
                studentNameEntry.setText("");
            }else {
                myRef.child("Student ID").setValue(studentID);
                myRef.child("Name").setValue(studentName);
            }

            Toast.makeText(this, "Person successfully added", Toast.LENGTH_SHORT).show();
        }
    }

    public void SettingsButtonIsClicked(View settingsButton){
        Intent intent = new Intent(this, SettingsScreen.class);
        startActivity(intent);
    }

    public void HomeButtonIsClicked(View homeButton){
        Intent intent = new Intent(this, StaffPortalDashboardScreen.class);
        startActivity(intent);
    }

    private void createNotificationChanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "testChanel";
            String description = "Chanel for test";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);

            NotificationManager x = getSystemService(NotificationManager.class);
            x.createNotificationChannel(channel);
        }
    }

    public void toggle(String command) throws CameraAccessException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;

            if (cameraManager != null) {
                cameraId = cameraManager.getCameraIdList()[0];
            }
            if (cameraManager != null) {
                if (command.equals("on")) {
                    cameraManager.setTorchMode(cameraId, true);
                } else {
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_add_screen);

        Spinner spinner = findViewById(R.id.roleChooser);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


        getLocalUser();

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.alarmsound);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Events");
        Log.i("MyTag", "id is: " + usernameOfLocalUser);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                panicIsTrue = Boolean.parseBoolean(dataSnapshot.child("panic").getValue().toString());

                if (panicIsTrue == true) {
                    mp.start();

                    try {
                        toggle("on");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                    createNotificationChanel();

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(PersonAddScreen.this, "test")
                            .setSmallIcon(R.drawable.ic_security_black_24dp)
                            .setContentTitle("Alert!")
                            .setContentText("There is a shooter on campus")
                            .setPriority(NotificationCompat.PRIORITY_HIGH);

                    Intent intent = new Intent(PersonAddScreen.this, InformationScreen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("message", "TEST");

                    PendingIntent pendingIntent = PendingIntent.getActivity(PersonAddScreen.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    builder.setContentIntent(pendingIntent);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(PersonAddScreen.this);
                    notificationManager.notify(100, builder.build());

                }

                if (panicIsTrue == false) {
                    mp.pause();
                    try {
                        toggle("off");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                }


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }

        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
        String text = parent.getItemAtPosition(position).toString();
        personRole = text;


    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        Toast.makeText(this, "You must select an option", Toast.LENGTH_SHORT).show();

    }
}
