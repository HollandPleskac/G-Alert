package com.luminos.developers.galert;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Dashboard extends AppCompatActivity {
    public static boolean panicIsTrue = false;
    public static String usernameOfLocalUser;


    public void getLocalUser(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_WORLD_READABLE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");

    }
    public void panicButtonIsClicked(View panicScreenButton){
        Intent intent = new Intent(this, panicButtonScreen.class);
        startActivity(intent);

    }

    public void suspicionIsClicked(View suspicionButton){
        Intent intent = new Intent(this, SuspicionScreen.class);
        startActivity(intent);

    }

    public void informationIsClicked(View informationButton){
        Intent intent = new Intent(this, InformationScreen.class);
        startActivity(intent);

    }
    private void createNotificationChanel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "testChanel";
            String description = "Chanel for test";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);

            NotificationManager x = getSystemService(NotificationManager.class);
            x.createNotificationChannel(channel);
        }
    }
    public void MapButtonIsClicked(View mapButton){
        Intent intent = new Intent(this, MapEscapeRoutesScreen.class);
        startActivity(intent);
    }

    public void toggle(String command) throws CameraAccessException {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            CameraManager cameraManager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;

            if(cameraManager != null){
                cameraId = cameraManager.getCameraIdList()[0];
            }
            if(cameraManager !=null){
                if(command.equals("on")){
                    cameraManager.setTorchMode(cameraId,true);
                }else{
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        }
    }

    public void SettingsButtonIsClicked(View settingsButton){
        Intent intent = new Intent(this, StudentInfoConfigureScreen.class);
        startActivity(intent);
    }

    public void logOutButtonIsClicked(View logOutButton) {
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, LoginScreen.class);
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        getLocalUser();

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.alarmsound);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Events");
        Log.i("MyTag", "id is: " + usernameOfLocalUser);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                panicIsTrue = Boolean.parseBoolean(dataSnapshot.child("panic").getValue().toString());

                if (panicIsTrue == true) {
                    mp.start();

                    try {
                        toggle("on");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                    createNotificationChanel();

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(Dashboard.this, "test")
                            .setSmallIcon(R.drawable.ic_security_black_24dp)
                            .setContentTitle("Alert!")
                            .setContentText("There is a shooter on campus")
                            .setPriority(NotificationCompat.PRIORITY_HIGH);

                    Intent intent = new Intent(Dashboard.this, InformationScreen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("message","TEST");

                    PendingIntent pendingIntent = PendingIntent.getActivity(Dashboard.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                    builder.setContentIntent(pendingIntent);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(Dashboard.this);
                    notificationManager.notify(100, builder.build());

                }

                if (panicIsTrue == false) {
                    mp.pause();
                    try {
                        toggle("off");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                }


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }

        });
    }


}

