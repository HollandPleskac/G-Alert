package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MapEscapeRoutesScreen extends AppCompatActivity{
    public static String usernameOfLocalUser;
    public static Object downloadURL;

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference myRef = firebaseDatabase.getReference();


    public void getLocalUser(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");

    }

    public void getDownloadURL(){
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                downloadURL = dataSnapshot.child("Schools").child(usernameOfLocalUser).child("MAP URL").child("imageurl").getValue();
                Log.i("MyTag", "Link is: " + downloadURL);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_escape_routes_screen);
        getLocalUser();
        getDownloadURL();

        ImageView map =findViewById(R.id.mapImage);
        String link = downloadURL + ""; //Retrieved url as mentioned above
        Glide
                .with(MapEscapeRoutesScreen.this)
                .load(link)
                .apply(new RequestOptions().placeholderOf(R.drawable.ic_location_off_black_24dp).error(R.drawable.ic_cloud_off_black_24dp))
                .into(map);
    }
}




