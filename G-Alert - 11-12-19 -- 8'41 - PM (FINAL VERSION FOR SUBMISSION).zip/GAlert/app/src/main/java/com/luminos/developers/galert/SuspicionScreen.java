package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SuspicionScreen extends AppCompatActivity {
    //  Global Strings
    public static boolean panicIsTrue = false;
    public static String usernameOfLocalUser;
    public static String currentDate;
    public static String IdofStudent;
    public static String currentTime;


    public void getLocalUser(){
        String x = "";
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");
        Log.i("MyTag",usernameOfLocalUser+"");
        IdofStudent = sharedPreferences.getString("studentID", "error");

    }
    public void suspicionButtonIsClicked(View suspicisonButton){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").
                child(usernameOfLocalUser);

        getDateAndTime();
        myRef.child("Event Log").child(currentDate + " - " + currentTime).child("Time pressed").setValue(currentTime);
        myRef.child("Event Log").child(currentDate + " - " + currentTime).child("Student Pressed").setValue(IdofStudent);
        myRef.child("Event Log").child(currentDate + " - " + currentTime).child("Date pressed").setValue(currentDate);
        myRef.child("Event Log").child(currentDate + " - " + currentTime).child("Event Type").setValue("2");


        Toast.makeText(this, "Your suspicion has been reported. Sit tight our staff will investigate shortly.", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, InformationScreen.class);
        startActivity(intent);
    }

    public void getDateAndTime(){
        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

    }

    public void dashboardButtonIsClicked(View dashboardButton){
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }
    public void toggle(String command) throws CameraAccessException {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            CameraManager cameraManager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;

            if(cameraManager != null){
                cameraId = cameraManager.getCameraIdList()[0];
            }
            if(cameraManager !=null){
                if(command.equals("on")){
                    cameraManager.setTorchMode(cameraId,true);
                }else{
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        }
    }

    private void createNotificationChanel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "testChanel";
            String description = "Chanel for test";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);

            NotificationManager x = getSystemService(NotificationManager.class);
            x.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suspicion_screen);
        getLocalUser();

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.alarmsound);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Events");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                panicIsTrue = Boolean.parseBoolean(dataSnapshot.child("panic").getValue().toString());



                if (panicIsTrue == true) {
                    mp.start();
                    try {
                        toggle("on");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                    createNotificationChanel();

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(SuspicionScreen.this, "test")
                            .setSmallIcon(R.drawable.ic_security_black_24dp)
                            .setContentTitle("Alert!")
                            .setContentText("There is a shooter on campus")
                            .setPriority(NotificationCompat.PRIORITY_HIGH);

                    Intent intent = new Intent(SuspicionScreen.this, InformationScreen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("message","TEST");

                    PendingIntent pendingIntent = PendingIntent.getActivity(SuspicionScreen.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                    builder.setContentIntent(pendingIntent);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(SuspicionScreen.this);
                    notificationManager.notify(100, builder.build());

                }

                if (panicIsTrue == false) {
                    mp.pause();
                    try {
                        toggle("off");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                }


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }

        });
    }
}
