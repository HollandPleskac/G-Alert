package com.luminos.developers.galert;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.Image;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StaffPortalDashboardScreen extends AppCompatActivity {
    public static String usernameOfLocalUser;
    public static String schoolID;
    public static boolean panicIsTrue = false;


    public void getLogEvents() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Event Log");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String student = snapshot.child("Student Pressed").getValue().toString();
                    String date = snapshot.child("Date pressed").getValue().toString();
                    String time = snapshot.child("Time pressed").getValue().toString();
                    String type = snapshot.child("Event Type").getValue().toString();
                    long numOfEvents = snapshot.getChildrenCount();

                    showLogEvent(time, date, student, numOfEvents, type);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void showLogEvent(String Time, String Date, String Student, long Num, String type) {

        if (Time.equals("") && Student.equals("") && Num == 1) {
            EditText noEvent = new EditText(this);
            noEvent.setText("No Events");
            noEvent.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            noEvent.setTextSize(30);

            ImageView alertImage = new ImageView(this);
            alertImage.setImageResource(R.drawable.ic_error_outline_black_24dp);
            alertImage.setMaxHeight(50);
            alertImage.setMaxWidth(50);

            LinearLayout main = findViewById(R.id.main);
            LinearLayout event = new LinearLayout(this);
            event.setOrientation(LinearLayout.HORIZONTAL);
            main.addView(event);

            event.addView(alertImage);
            event.addView(noEvent);
        } else {
            if (Date.equals("No Event")) {

            } else {
                //  Warning Image
                ImageView alertImage = new ImageView(this);
                alertImage.setMaxHeight(50);
                alertImage.setMaxWidth(50);
                if (type.equals("1")) {
                    //  For Suspicion Event Image
                    alertImage.setImageResource(R.drawable.ic_error_outline_black_24dp);
                } else {
                    // For Panic Event Image
                    alertImage.setImageResource(R.drawable.ic_visibility_off_black_24dp);
                }
                //  Edit Texts
                EditText time = new EditText(this);
                time.setText("Time: \n" + Time);

                EditText date = new EditText(this);
                date.setText("Date: \n" + Date);

                EditText student = new EditText(this);
                student.setText("ID: \n" + Student);

                // Dynamically add views
                LinearLayout main = findViewById(R.id.main);
                LinearLayout event = new LinearLayout(this);
                event.setOrientation(LinearLayout.HORIZONTAL);
                main.addView(event);

                event.addView(alertImage);
                event.addView(time);
                event.addView(date);
                event.addView(student);
            }
        }

    }

    public void logOutButtonIsClicked(View logOutButton) {
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, StaffLogin.class);
        startActivity(intent);
    }

    public void getLocalUser() {
        String x = "";
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username", "error");
        Log.i("MyTag", usernameOfLocalUser + "");

    }

    public void panicButtonIsClicked(View panicButton) {
        Intent intent = new Intent(this, StaffPanicButtonScreen.class);
        startActivity(intent);
    }

    public void SettingsButtonIsClicked(View settingsButton) {
        Intent intent = new Intent(this, SettingsScreen.class);
        startActivity(intent);
    }

    public void addPersonButtonIsClicked(View person_add_button) {
        Intent intent = new Intent(this, PersonAddScreen.class);
        startActivity(intent);
    }

    public void displaySchoolID() {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Information");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                schoolID = dataSnapshot.child("School ID").getValue().toString();

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });


        TextView schoolIDLabel = findViewById(R.id.schoolIDlabel);
        schoolIDLabel.setText(usernameOfLocalUser + "");

    }

    private void createNotificationChanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "testChanel";
            String description = "Chanel for test";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);

            NotificationManager x = getSystemService(NotificationManager.class);
            x.createNotificationChannel(channel);
        }
    }

    public void toggle(String command) throws CameraAccessException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;

            if (cameraManager != null) {
                cameraId = cameraManager.getCameraIdList()[0];
            }
            if (cameraManager != null) {
                if (command.equals("on")) {
                    cameraManager.setTorchMode(cameraId, true);
                } else {
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        }
    }
    public void refreshButtonIsClicked(View refreshButton){
        LinearLayout x = findViewById(R.id.main);
        x.removeAllViews();
        getLogEvents();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_portal_dashboard_screen);

        getLocalUser();
        displaySchoolID();
        getLogEvents();

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.alarmsound);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Events");
        Log.i("MyTag", "id is: " + usernameOfLocalUser);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                panicIsTrue = Boolean.parseBoolean(dataSnapshot.child("panic").getValue().toString());

                if (panicIsTrue == true) {
                    mp.start();

                    try {
                        toggle("on");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                    createNotificationChanel();

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(StaffPortalDashboardScreen.this, "test")
                            .setSmallIcon(R.drawable.ic_security_black_24dp)
                            .setContentTitle("Alert!")
                            .setContentText("There is a shooter on campus")
                            .setPriority(NotificationCompat.PRIORITY_HIGH);

                    Intent intent = new Intent(StaffPortalDashboardScreen.this, InformationScreen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("message", "TEST");

                    PendingIntent pendingIntent = PendingIntent.getActivity(StaffPortalDashboardScreen.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    builder.setContentIntent(pendingIntent);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(StaffPortalDashboardScreen.this);
                    notificationManager.notify(100, builder.build());

                }

                if (panicIsTrue == false) {
                    mp.pause();
                    try {
                        toggle("off");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                }


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }

        });
    }
}
