package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.model.Dash;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StudentInfoConfigureScreen extends AppCompatActivity {
    // Edit text objects
    EditText numberOne;
    EditText numberTwo;
    EditText relationOne;
    EditText relationTwo;

    //Global Variables
    public static String numberOneInt;
    public static String numberTwoInt;
    public static String relationOneString;
    public static String relationTwoString;
    public static String usernameOfLocalUser;
    public static String IdofStudent;

    public void SubmitButtonIsClicked(View submitButton){
        // Configure Edit texts
        numberOne = findViewById(R.id.numberOne);
        numberTwo = findViewById(R.id.numberTwo);
        relationOne = findViewById(R.id.relationOne);
        relationTwo = findViewById(R.id.relationTwo);

        // Gets values and stores them
        numberOneInt = numberOne.getText().toString();
        numberTwoInt = numberTwo.getText().toString();
        relationOneString = relationOne.getText().toString();
        relationTwoString = relationTwo.getText().toString();

        Toast.makeText(this, "Settings Updated!", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Student").child(IdofStudent);

        myRef.child("Phone Number One").setValue(numberOneInt);
        myRef.child("Phone Number Two").setValue(numberTwoInt);
        myRef.child("Relation One").setValue(relationOneString);
        myRef.child("Relation Two").setValue(relationTwoString);



    }

    public void dashboardButtonIsClicked(View dashboardButton){
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }

    public void getLocalUser(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");
        Log.i("MyTag",usernameOfLocalUser+"");
        IdofStudent = sharedPreferences.getString("studentID", "error");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_info_configure_screen);
        getLocalUser();
    }
}
