package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StaffLogin extends AppCompatActivity {

    public static String schoolIDbYUser;

    //defines the global strings of the program
    public static String username;
    public static String password;

    public void saveLocallyCredentials(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        Log.i("MyTag",username);
        editor.apply();

    }
    //Login Button Clicked Event handler
    public void LoginButtonIsPressed (View loginButton) {
        //initializes edit texts
        EditText usrEntry = findViewById(R.id.student_id_input);
        EditText passEntry = findViewById(R.id.password_entry);

        //Values of user input
        schoolIDbYUser = usrEntry.getText().toString();
        String passwordByUser = passEntry.getText().toString();


        //Firebase Initilize
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(schoolIDbYUser).child("Information");

        //gets values from database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                username = dataSnapshot.child("School ID").getValue().toString();
                password = dataSnapshot.child("Password").getValue().toString();
                Log.i("MyTag","Value is: " + username + " :" + password);
                ValidateLogin();

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(StaffLogin.this, "Password Is Incorrect", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void backButtonIsClicked(View backButton){
        Intent intent = new Intent(this, LoginScreen.class);
        startActivity(intent);
    }
    //Function that opens up the signup screen
    public void openAfterLoginScreen () {
        Intent intent = new Intent(this, StaffPortalDashboardScreen.class);
        startActivity(intent);
    }
    public void openSignUpScreen () {
        Intent intent = new Intent(this, StaffSignUpScreen.class);
        startActivity(intent);
    }



    //Validates the login
    public void ValidateLogin() {
        //initializes the edit texts
        EditText usrEntry = findViewById(R.id.student_id_input);
        EditText passEntry = findViewById(R.id.password_entry);

        //Values of user input
        String usernameByUser = usrEntry.getText().toString();
        String passwordByUser = passEntry.getText().toString();


        Log.i("MyTag","Value is: " + username + " :" + password);
        if (usernameByUser.equals(username) && passwordByUser.equals(password)) {
            Toast.makeText(this, "Login Success", Toast.LENGTH_SHORT).show();
            openAfterLoginScreen();
            saveLocallyCredentials();
        }
        else {
            Log.i("MyTag", "Unsuccessful");
            Toast.makeText(this, "Login Failure", Toast.LENGTH_SHORT).show();
        }
    }

    public void signUpButtonIsPressed(View signUpButton) {

        openSignUpScreen();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_login);
    }
}
