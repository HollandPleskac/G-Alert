package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StaffPortalDashboardScreen extends AppCompatActivity {
    public static String usernameOfLocalUser;
    public static String schoolID;

    public void getLocalUser(){
        String x = "";
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");
        Log.i("MyTag",usernameOfLocalUser+"");

    }

    public void addStudentButtonIsClicked(View addStudentButton){

        EditText studentIDEntry = findViewById(R.id.studentIdEntry);
        EditText studentNameEntry = findViewById(R.id.studentNameEntry);

        String studentID = studentIDEntry.getText().toString();
        String studentName = studentNameEntry.getText().toString();

        if (studentID.equals("") || studentName.equals("")){
            Toast.makeText(this, "Fields cannot be left blank!", Toast.LENGTH_SHORT).show();
        } else {

            //Firebase Initilize
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Students").child(studentID);

            myRef.child("Student ID").setValue(studentID);
            myRef.child("Student Name").setValue(studentName);
        }
    }

    public void displaySchoolID(){

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Information");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                schoolID = dataSnapshot.child("School ID").getValue().toString();

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });




        TextView schoolIDLabel = findViewById(R.id.school_ID_input);
        schoolIDLabel.setText(usernameOfLocalUser + "");

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_portal_dashboard_screen);

        getLocalUser();
        displaySchoolID();
    }
}
