package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class StaffSignUpScreen extends AppCompatActivity {
    public static int schoolID;

    public void signUpButtonIsPressed(View signUpButton){
        EditText schoolNameEntry = findViewById(R.id.name_entry);
        EditText passwordEntry = findViewById(R.id.password_entry);
        EditText emailEntry = findViewById(R.id.email_entry);
        EditText passwordReEntry = findViewById(R.id.password_re_entry);

        String schoolName = schoolNameEntry.getText().toString();
        String pass = passwordEntry.getText().toString();
        String Repass = passwordReEntry.getText().toString();


        if (pass.equals(Repass)){
            // FireBase Initialization
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("Schools").child(schoolID+"").child("Information");

            myRef.child(schoolName);
            myRef.child("Password").setValue(passwordEntry.getText().toString());
            myRef.child("Email").setValue(emailEntry.getText().toString());
            myRef.child("School Name").setValue(schoolNameEntry.getText().toString());

            myRef.child("School ID").setValue(schoolID + "");

            Toast.makeText(this, "You have signed up the school. Now login to add accounts and other info.-", Toast.LENGTH_LONG).show();

            Intent intent = new Intent(this, StaffLogin.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(this, "Password and repeat password do not match", Toast.LENGTH_LONG).show();
        }

    }

    public void generateSchoolID(){
        Random r = new Random();
        schoolID = r.nextInt(9999999 - 1000000) + 1000000;

        TextView schoolIDLabel = findViewById(R.id.school_ID_input);
        schoolIDLabel.setText(schoolID + "");
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_sign_up_screen);

        generateSchoolID();

    }
}
