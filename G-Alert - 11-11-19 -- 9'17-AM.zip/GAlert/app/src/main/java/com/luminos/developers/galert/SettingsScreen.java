package com.luminos.developers.galert;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.util.HashMap;
import java.util.Set;

import static java.lang.String.valueOf;

public class SettingsScreen extends AppCompatActivity {
    //  Global Variables
    FirebaseStorage storage;
    FirebaseDatabase database;
    public static String usernameOfLocalUser;
    ProgressDialog progressDialog;
    UploadTask uploadTask;
    Uri imageUri;
    EditText passEntry;
    EditText passReEntry;
    public static boolean panicIsTrue = false;

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference myRef = firebaseDatabase.getReference();

    public void changePasswordButtonIsClicked(View changePasswordButton){
        passEntry = findViewById(R.id.passwordEntry);
        passReEntry = findViewById(R.id.passwordReEntry);

        String password = passEntry.getText().toString();
        String passwordReEnterText = passReEntry.getText().toString();

        if (password.equals(passwordReEnterText)){
            myRef.child("Schools").child(usernameOfLocalUser).child("Information").child("Password").setValue(password);
            Toast.makeText(this, "Password Successfully Changed!", Toast.LENGTH_SHORT).show();
        } else{
            Toast.makeText(this, "Password and repeat password do not match!", Toast.LENGTH_SHORT).show();
        }

    }
    public void deleteYes(){
        Toast.makeText(this, "Account Deleted", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, StaffLogin.class);
        startActivity(intent);
    }

    public void deleteAccountButtonIsClicked(View deleteMapButton){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Account?")
                .setMessage("Are you sure you want to delete your account?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteYes();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
        builder.create();
        builder.show();

    }
    public void getLocalUser(){
        String x = "";
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");
        Log.i("MyTag",usernameOfLocalUser+"");

    }

    public void AddMapButtonIsClicked(View addMapButton){

        storage = FirebaseStorage.getInstance();
        database = FirebaseDatabase.getInstance();

        if(ContextCompat.checkSelfPermission(SettingsScreen.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
            selectImage();

        } else{
            ActivityCompat.requestPermissions(SettingsScreen.this, new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE}, 9);
        }

    }

    public void uploadButtonIsPressed(View uploadButton){
        if (imageUri != null){
            uploadFile(imageUri);
                } else{
                    Toast.makeText(SettingsScreen.this, "Select a file", Toast.LENGTH_SHORT).show();
                }
    }

    public void uploadFile(Uri imageUri){
        progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle("Uploading file...");
        progressDialog.setProgress(0);
        progressDialog.show();
        final StorageReference storageReference = storage.getReference(usernameOfLocalUser+"/map.jpeg");
        storageReference.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Toast.makeText(SettingsScreen.this, "Upload Success", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();

                        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                HashMap<String, String> hashMap = new HashMap<>();
                                hashMap.put("imageurl", String.valueOf(uri));
                                myRef.child("Schools").child(usernameOfLocalUser).child("MAP URL").setValue(hashMap);
                            }
                        });

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(SettingsScreen.this, "File not successfully uploaded", Toast.LENGTH_SHORT).show();

            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                int currentProgress = (int) (100 * taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                progressDialog.setProgress(currentProgress);


            }
        });


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 9 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            selectImage();
        } else{
            Toast.makeText(this, "Storage Permissions not Granted", Toast.LENGTH_SHORT).show();
        }
    }

    public void selectImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,86);
    }


    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == 86 && resultCode == RESULT_OK && data != null){
            imageUri = data.getData();
            
        } else{
            Toast.makeText(this, "Please select a valid image file", Toast.LENGTH_SHORT).show();
        }
    }

    public void AddPersonButtonIsClicked(View person_add_button){
        Intent intent = new Intent(this, SettingsScreen.class);
        startActivity(intent);
    }

    public void HomeButtonIsClicked(View homeButton){
        Intent intent = new Intent(this, StaffPortalDashboardScreen.class);
        startActivity(intent);
    }

    private void createNotificationChanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "testChanel";
            String description = "Chanel for test";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);

            NotificationManager x = getSystemService(NotificationManager.class);
            x.createNotificationChannel(channel);
        }
    }

    public void toggle(String command) throws CameraAccessException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String cameraId = null;

            if (cameraManager != null) {
                cameraId = cameraManager.getCameraIdList()[0];
            }
            if (cameraManager != null) {
                if (command.equals("on")) {
                    cameraManager.setTorchMode(cameraId, true);
                } else {
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_screen);

        getLocalUser();

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.alarmsound);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Schools").child(usernameOfLocalUser).child("Events");
        Log.i("MyTag", "id is: " + usernameOfLocalUser);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                panicIsTrue = Boolean.parseBoolean(dataSnapshot.child("panic").getValue().toString());

                if (panicIsTrue == true) {
                    mp.start();

                    try {
                        toggle("on");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                    createNotificationChanel();

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(SettingsScreen.this, "test")
                            .setSmallIcon(R.drawable.ic_security_black_24dp)
                            .setContentTitle("Alert!")
                            .setContentText("There is a shooter on campus")
                            .setPriority(NotificationCompat.PRIORITY_HIGH);

                    Intent intent = new Intent(SettingsScreen.this, InformationScreen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("message", "TEST");

                    PendingIntent pendingIntent = PendingIntent.getActivity(SettingsScreen.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    builder.setContentIntent(pendingIntent);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(SettingsScreen.this);
                    notificationManager.notify(100, builder.build());

                }

                if (panicIsTrue == false) {
                    mp.pause();
                    try {
                        toggle("off");
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }

                }


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }

        });
    }
}
