package com.luminos.developers.galert;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginScreen extends AppCompatActivity {
    //Global Strings
    public static String idBySchool;
    public static String username;
    public static String password;

    public void saveLocallyCredentials(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", idBySchool);
        editor.putString("studentID", username);
        editor.apply();

    }
    //Login Button Clicked Event handler
    public void LoginButtonIsClicked (View loginButton) {
        try {
            //initializes edit texts
            EditText StudentIDEntry = findViewById(R.id.student_id_input);
            EditText SchoolIDEntry = findViewById(R.id.school_id_input);

            //Values of user input
            String IdOfStudent = StudentIDEntry.getText().toString();
            idBySchool = SchoolIDEntry.getText().toString();

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("Schools").child(idBySchool).child("Student").child(IdOfStudent);

            //gets values from database
            myRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.
                    username = dataSnapshot.child("Student ID").getValue().toString();
                    password = dataSnapshot.child("Name").getValue().toString();
                    Log.i("MyTag", "Value is: " + username + " :" + password);
                    openAfterLoginScreen();

                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value
                    Toast.makeText(LoginScreen.this, "Username Not Found", Toast.LENGTH_SHORT).show();
                }
            });
        } catch(NullPointerException e){
            Toast.makeText(this, "Login Invalid", Toast.LENGTH_SHORT).show();
        }
    }

    //Function that opens up the signup screen
    public void openAfterLoginScreen(){
        saveLocallyCredentials();
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }
    public void openSignUpScreen(){
        Intent intent = new Intent(this, StaffLogin.class);
        startActivity(intent);
    }



    //Validates the login
    public void signUpButtonIsPressed(View signUpButton) {

        openSignUpScreen();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

    }
}
